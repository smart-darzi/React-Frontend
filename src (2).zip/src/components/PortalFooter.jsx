import React from 'react';
import { Scissors, Phone } from 'lucide-react';

// Shared footer for the Customer and Worker portals — closes out the page
// with the shop's own mark rather than just trailing off after the last
// section. Kept static (no live settings are wired into these portals yet).
// Always a single row, at every screen size — text/icons shrink instead of
// wrapping onto a second line, and the least essential bits (tagline,
// contact hint) drop off below sm so the row never breaks.
const PortalFooter = () => (
  <footer className="pt-2">
    <div className="flex flex-row items-center justify-between gap-2 sm:gap-4 border-t border-primary/10 pt-4 sm:pt-6">
      <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
        <span className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
          <Scissors size={11} className="sm:w-[14px] sm:h-[14px]" />
        </span>
        <div className="min-w-0">
          <p className="font-display text-[10px] sm:text-sm font-extrabold text-slate-700 leading-tight truncate">Smart Master</p>
          <p className="hidden sm:block text-slate-400 text-[11px] font-medium leading-tight">Tailoring, done right</p>
        </div>
      </div>
      <div className="flex items-center gap-2 sm:gap-4 text-slate-400 text-[9px] sm:text-xs font-medium flex-shrink-0">
        <span className="hidden md:flex items-center gap-1.5"><Phone size={12} /> Contact the shop for any questions</span>
        <span className="hidden md:inline text-slate-300">·</span>
        <span className="whitespace-nowrap">© {new Date().getFullYear()} Smart Master</span>
      </div>
    </div>
  </footer>
);

export default PortalFooter;
